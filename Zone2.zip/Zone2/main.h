//
// main.h
//
// Constants used for zone2 controls and macros for bitwise operations
//
//
//

#ifndef MAIN_H_
#define MAIN_H_


//Macros for bitwise operations
//Try to avoid the stuipd logic errors that
//take a long time to debug
#define BitSet(arg,bits) ((arg) |= (bits))
#define BitClear(arg,bits) ((arg) &= ~(bits))
#define BitFlip(arg,bits) ((arg) ^= (bits))
#define BitTest(arg,bits) ((arg) & (bits))




/*
 *  ======== MCU Pin Definitions ========
 */
//Port 1
#define SPARE      BIT0
#define btnTUNER   BIT3
#define btnTV      BIT4
#define btnMUTE    BIT5
#define btnSTATUS  BIT6
#define btnAUX     BIT7
#define NOBUTTONS btnTV+btnSTATUS+btnTUNER+btnAUX+btnMUTE

//Port 2
#define encCH_A    BIT0
#define encCH_B    BIT1
#define ledMUTE    BIT2
#define ledSTSGRN  BIT3
#define ledSTSRED  BIT4
#define ledAUX     BIT5
#define ledTV      BIT6
#define ledTUNER   BIT7

//Constants used by QueTX function
#define txZ2INFO   1
#define txZ2UP     2
#define txZ2DOWN   3
#define txZ2AUX    4
#define txZ2TUNER  5
#define txZ2TV     6
#define txZ2MUTE   7
#define txZ2UNMUTE 8
#define txZ2ON     9
#define txZ2OFF    10

#define MUTEOFF    0
#define MUTEON     1

#define srcUNK     0
#define srcCD      1
#define srcTV      2
#define srcTUNER   3

#define Z2PWR_ON   1
#define Z2PWR_OFF  0
#define Z2PWR_UNK  20

//button is used as a flag from interrupts to back to main loop
//these are mainly button presses but also WDT trigger
#define BUTTON_UP  1
#define BUTTON_DOWN 2
#define BUTTON_STS 3  //Toggle power
#define BUTTON_MUTE 4
#define BUTTON_AUX 5
#define BUTTON_TUNER 6
#define BUTTON_TV 7
#define BUTTON_WAIT 22  //used to avoid repeating
#define BUTTON_WDT 8

#endif /* MAIN_H_ */
