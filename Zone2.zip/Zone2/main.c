/*
 * ======== Standard MSP430 includes ========
 */
#include <msp430.h>

/*
 * ======== Grace related includes ========
 */
#include <ti/mcu/msp430/Grace.h>

/*
 *  ======== Bit manipulation macros ========
 */
#include "main.h"

/*
 *  ======== main ========
 */

//Half of the RAM is dedicated to the buffers
char txBuffer[64];
char rxBuffer[64];

unsigned int index=0;
signed int quadCounts=0;
unsigned int debounce=0;
unsigned int button=BUTTON_WDT;
unsigned char old_AB=0;
signed const char enc_states[] = {0,-1,1,0,1,0,0,-1,-1,0,0,1,0,1,-1,0};

char vol1='1';
char vol2='0';


//Variables to track position in rx buffer
unsigned int rxRead=0x3F;
unsigned int rxWrite=0;
unsigned int rxCtr=0;


//Variables to track position in tx buffer
unsigned int txRead=0x3F;
unsigned int txWrite=0;
unsigned int txCtr=0;



unsigned int muted=MUTEOFF;
unsigned int source=srcUNK;
unsigned int z2pwr=Z2PWR_UNK;
unsigned int tunerPreset=0;
unsigned int pwrOnDelay=0;

unsigned int rxError=0;


//Helper function to get next char from rx buffer
char rxGet(void)
{
	rxRead = (rxRead+1) & 0x3F;
	return rxBuffer[rxRead];
}



//Helper function to put char on tx buffer
void txPut(char val)
{
	//Advance txWrite pointer and roll over from 63 to 0
	txWrite = (txWrite+1) & 0x3F;
	txBuffer[txWrite] = val;
}

//Add command to tx buffer to set desired tuner frequency
//Frequencies are hard coded but it almost easier to change them in the
//wall control than figure out how to set the presets on the receiver
//itself
void QueTuner(unsigned int value)
{
	//Different command for Tuner
	//doesn't start with Z2 as tuner is shared
	//TF010590 for 105.9


	//All commands start with the same prefix
	//(Had this in the switch before, pulling it out saved a ton of flash space)
	txPut('T');
	txPut('F');
	txPut('0');

	switch (value)
	{
		case 0:  //105.9
		{
			txPut('1');
			txPut('0');
			txPut('5');
			txPut('9');
			break;
		}
		case 1:  //102.5
		{
			txPut('1');
			txPut('0');
			txPut('2');
			txPut('5');
			break;
		}
		case 2:  //96.1
		{
			txPut('0');
			txPut('9');
			txPut('6');
			txPut('1');
			break;
		}
		case 3:  //93.7
		{
			txPut('0');
			txPut('9');
			txPut('3');
			txPut('7');
			break;
		}
		case 4:  //94.5
		{
			txPut('0');
			txPut('9');
			txPut('4');
			txPut('5');
			break;
		}
		case 5:  //96.9
		{
			txPut('0');
			txPut('9');
			txPut('6');
			txPut('9');
			break;
		}


	}  //End switch

	txPut('0');
	txPut('\r');

	//Add new item to send
	txCtr++;

	//Turn on the tx Interrupt
	BitSet(IE2, UCA0TXIE);
}


//Add new item to the tx buffer based on the value provided
void QueTX(unsigned int value)
{
	txPut('Z');
	txPut('2');

	switch (value)
	{
		case txZ2INFO:
		{
			txPut('?');  //sending a ? returns the current tuner information
			break;
		}
		case txZ2UP:  //Volume up
		{
			txPut('U');
			txPut('P');
			break;
		}
		case txZ2DOWN:  //Volume down
		{
			txPut('D');
			txPut('O');
			txPut('W');
			txPut('N');
			break;
		}
		case txZ2ON:  //Zone 2 power on
		{
			txPut('O');
			txPut('N');
			break;
		}
		case txZ2OFF:  //Zone 2 power off
		{
			txPut('O');
			txPut('F');
			txPut('F');
			break;
		}
		case txZ2AUX:  //Select the CD input as source,  hooked up to an auxiliary input cable for MP3 player
		{
			txPut('C');
			txPut('D');
			break;
		}
		case txZ2TUNER:  //Select the tuner as source
		{
			txPut('T');
			txPut('U');
			txPut('N');
			txPut('E');
			txPut('R');
			tunerPreset=0;  //Initialize to first preset
			break;
		}
		case txZ2TV:  //Select the TV input as source
		{
			txPut('T');
			txPut('V');
			break;
		}
		case txZ2MUTE:  //Z299 sets volume to 99 which is muted.
		{
			txPut('9');
			txPut('9');
			break;
		}
		case txZ2UNMUTE:  //To unmute send stored prior volume
		{
			txPut(vol1);
			txPut(vol2);
			break;
		}
		default:
		{  //Send info request for unhandled switch value
			txPut('?');
			break;
		}

	}  //end switch


	//Add termination, increment counter, and turn on Tx interrupt
	txPut('\r');
	txCtr++;
	BitSet(IE2, UCA0TXIE);

}


//Function to process rx buffer item
void DoRX(void)
{
	//Vars used to process rx items
	char tmp;
	char tmp2;

	tmp=rxGet();

	//Most responses of concern with start with "Z2"
	//After matching loop reads in remaining characters to the \r

	//If first character is 'Z'
	if(tmp=='Z')
	{
		tmp=rxGet();

		//If second character is '2'
		if(tmp=='2')
		{

			tmp=rxGet();

			//See if it is a number for the volume
			if(tmp>='0' && tmp<='9')
			{

				tmp2=rxGet();

				//make sure next character is a number too
				if(tmp2>='0' && tmp2<='9')
				{
					//Check to see if MUTED
					if(tmp=='9' && tmp2=='9')
					{
						muted = MUTEON;
						if(z2pwr==Z2PWR_ON)
						{
							BitSet(P2OUT,ledMUTE);
						}
					}
					else //wasn't Z299
					{
						vol1=tmp;
						vol2=tmp2;
						muted = MUTEOFF;
						BitClear(P2OUT,ledMUTE);
					}
				}
				else
				{
					//Unexpected, both were not numbers so default to 10 (min volume)
					vol1='1';
					vol2='0';
					muted = MUTEOFF; //assume mute is off
					BitClear(P2OUT,ledMUTE);
					QueTX(txZ2INFO);  //Get current status to eliminate unexpected condition
				}
			}
			//3rd character not a number
			else
			{
				//4th character used to distinguish
				tmp=rxGet();

				if(tmp=='N')  //ON
				{
					BitSet(P2OUT, ledSTSGRN);
					BitClear(P2OUT, ledSTSRED);
					if(z2pwr!=Z2PWR_ON)
						QueTX(txZ2INFO);  //Get current status whenever turning on
					z2pwr = Z2PWR_ON;
				}

				if(tmp=='F')  //OFF
				{
					BitSet(P2OUT, ledSTSRED);
					BitClear(P2OUT, ledSTSGRN + ledTV + ledAUX + ledTUNER + ledMUTE);
					pwrOnDelay = 0;
					z2pwr = Z2PWR_OFF;
				}

				if(tmp=='V')  //TV  (or DVD)
				{
					if(z2pwr==Z2PWR_ON)
						BitSet(P2OUT, ledTV);
					BitClear(P2OUT, ledAUX + ledTUNER);
					source = srcTV;
				}

				if(tmp=='U')  //TUNER
				{
					if(z2pwr==Z2PWR_ON)
						BitSet(P2OUT, ledTUNER);
					BitClear(P2OUT, ledAUX + ledTV);
					source=srcTUNER;
				}

				if(tmp=='D')  //CD  (or CDR)
				{
					if(z2pwr==Z2PWR_ON)
						BitSet(P2OUT, ledAUX);
					BitClear(P2OUT, ledTV + ledTUNER);
					source=srcCD;
				}

			}

		}  // second char 2
	}  //first char Z

	//First character wasn't 'Z' see if it is PWON
	// PWON is sent went power is first applied
	// There is an 8 second delay before audio output
	// is sent, flash the STS green led during wait
	// otherwise, STS is solid green but no audio
	// if main zone is already on then there is no
	// PWON transmitted.
	else if (tmp=='P')
	{
		tmp=rxGet();

		//If second character is 'W'
		if(tmp=='W')
		{
			tmp=rxGet();

			//If third character is 'O'
			if(tmp=='O')
			{
				tmp=rxGet();

				//If forth character is 'N'
				if(tmp=='N')
				{
					pwrOnDelay=800;  //About an 8 second turn on delay 800 * 10ms = 8 seconds
				}

			}

		}

	}


	//Read rest of current input including the \r
	while(tmp != '\r')
	{
		tmp = rxGet();
	}

	//This rx item has been processed
	rxCtr--;

	if (rxCtr == 0)
	{
		//Set rxRead to the rxWrite location when rxCtr is zero.  This keeps the read buffer from getting out of sync with write location
		//if the receiver sends gibberish without at \r termination
		rxRead=rxWrite;
	}
}




int main(void)
{
	//TI Grace / MSP430Ware GUI used for configuring module
	//Hardware config is stable, wish they had an option to
	//convert Grace_init() into one function in main.c
	Grace_init();

	//Initialize rxBuffer
	for(rxWrite=0; rxWrite<64; rxWrite++)
		rxBuffer[rxWrite]='\r';
	rxWrite=0x3F;

	//Initialize txBuffer
	for(txWrite=0; txWrite<64; txWrite++)
		txBuffer[txWrite]='\r';
    txWrite=0x3F;

    //Get the current state, make sure it returns before entering the main loop
    //Red STS led will flash during this state
    while(z2pwr==Z2PWR_UNK)
    {

    	if(button==BUTTON_WDT)
    	{
    	  	//slow flash of Red Status Led until connected
    		BitFlip(P2OUT, ledSTSRED);
    		QueTX(txZ2INFO);
    	}

		button=0;

		__bis_SR_register(LPM0_bits + GIE);

		//Process any responses
		while(rxCtr > 0)
			DoRX();

    }

    //Grace configuration has WDT interval at approximately 680 ms (/8192) to get initial state
    //Stop WDT after initial state is obtained
    WDTCTL = WDTPW + WDTHOLD;

	while(1)
	{

		if(button != 0)
		{
			if(button == BUTTON_UP)
			{
				//Up pressed
				QueTX(txZ2UP);
			}
			if(button == BUTTON_DOWN)
			{
				//DOWN pressed
				QueTX(txZ2DOWN);
			}

			if(button == BUTTON_STS)
			{
				//STS pressed
				if(z2pwr == Z2PWR_ON)
					QueTX(txZ2OFF);

				if(z2pwr == Z2PWR_OFF)
				{
					QueTX(txZ2ON);
				}
			}

			if(button == BUTTON_MUTE)
			{
				//MUTE pressed
				if(muted == MUTEON)
					QueTX(txZ2UNMUTE);

				if(muted == MUTEOFF)
					QueTX(txZ2MUTE);
			}

			if(button == BUTTON_AUX)
			{
				//AUX pressed
				QueTX(txZ2AUX);
			}

			if(button == BUTTON_TUNER)
			{
				if(source==srcTUNER)
				{
					QueTuner(tunerPreset);
					tunerPreset++;
					if(tunerPreset==6)
						tunerPreset=0;
				}
				else
				{
					//Tuner wasn't current source so select tuner but don't change station
					//might have set it manually to something not in hard coded list
					QueTX(txZ2TUNER);
				}

			}

			if(button == BUTTON_TV)
			{
				//TV pressed
				QueTX(txZ2TV);
			}

			//Wait flag used to keep from repeating press
			button=BUTTON_WAIT;

		}


		//If there is stuff to process look at it, otherwise go to sleep
		if(rxCtr >0)
		{
			DoRX();
		}
		else
		{
			__bis_SR_register(LPM0_bits + GIE);       // Enter LPM0, interrupts enabled

		}

	}
}

